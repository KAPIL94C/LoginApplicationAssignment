package com.capg.loginapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.loginapp.services.UserDAOImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cookie arr[] = request.getCookies();
		String cookieValue = null;
		if (arr != null) 
		{
			for (Cookie cookie : arr) {
				String cookieName = cookie.getName();
				if (cookieName.equals("cookieUsername")) {
					cookieValue = cookie.getValue();
					break;
				}
			}
		}
		
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.print("<HTML><BODY>");
		out.print("<FORM method='post' action='login'>");

		if (cookieValue == null)
			out.print("username <input type='text' name='username'><br/>");
		if (cookieValue != null)
			out.print("username <input type='text' name='username' value='" + cookieValue + "'><br/>");
		
		out.print("password <input type='text' name='password'><br/>");
		out.print("<input type='checkbox' name='rememberme' value='rememberme'> Remember Me<br/>");

		out.print("<input type='submit'><br/>");

		out.print("</FORM>");
		out.print("</BODY></HTML>");	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
		String rememberme = request.getParameter("rememberme");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		
		UserDAOImpl dao = UserDAOImpl.getUserDAOImplObject();
		boolean isValidUser = dao.validateUser(username, password);
		
		
		if (isValidUser) {
			System.out.println(" WELCOME!! ");
			
			if (rememberme != null) {
				Cookie cook = new Cookie("cookieUsername", username);
				cook.setMaxAge(1000 * 60 * 60 * 24);
				response.addCookie(cook);

				System.out.println(" Cookie Added SUCCESSFULLY");
			}

			// if valid move to Welcome page
			request.setAttribute("username", username);
			request.getRequestDispatcher("WelcomeServlet").forward(request, response);
		} else {
			response.sendRedirect("login");
		}
	}

}
