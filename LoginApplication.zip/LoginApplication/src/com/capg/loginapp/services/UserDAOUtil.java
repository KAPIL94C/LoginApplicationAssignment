package com.capg.loginapp.services;

import java.util.HashMap;
import java.util.Map;


public class UserDAOUtil {
	
	public static Map<String, String> userDB = new HashMap<String, String>();

	static
	{
		userDB.put("kapil","kapil");
		userDB.put("vipin","vipin");
		
	}
	
	public static Map<String, String> getDB(){
		return userDB;
	}

}
