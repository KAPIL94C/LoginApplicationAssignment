package com.capg.loginapp.services;

public interface UserDAO {
	
	public boolean validateUser(String username,String password);

}
